﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VendorsManagmentApp.Services
{
    public static class InvoicesServices
    {

        public static int vendorId { get; set; }
        public static int invoiceId { get; set; }
        public static string sortOrder { get; set; }
        public static string sortOrderIndex { get; set; }
        public static string retuendLink { get; set; }

    }
}
